# Paisa Android APK project

This is an Android Studio project wrapping the Paisa offline expense tracker in a native Android WebView shell. It uses the same local-only HTML/JavaScript app, with browser DOM storage enabled.

## Build APK using Android Studio
1. Install Android Studio on a supported Windows/macOS/Linux computer.
2. Open this folder (`PaisaAndroid`) as an existing project.
3. Allow Gradle sync and install Android SDK Platform 35 if prompted.
4. Select **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
5. The debug APK will be at `app/build/outputs/apk/debug/app-debug.apk`.
6. Transfer the APK to your Android phone, open it, and allow installation from that source if Android asks.

## Important
- This source project is not itself a compiled APK. This environment has Java but no Android SDK or Gradle installation, so it cannot produce or verify an installable APK here.
- The app works offline and stores entries locally on the device. Clearing app data/uninstalling may erase records; use Export CSV in the app for backups.
- No internet permission is requested. No bank credentials or cloud account are used.
