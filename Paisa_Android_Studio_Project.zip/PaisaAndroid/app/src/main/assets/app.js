const KEY='paisa_transactions_v1';
const CATS=[['Food','🍲'],['Travel','🛺'],['Shopping','🛍️'],['Bills','🧾'],['Medical','💊'],['Education','📚'],['Salary','💼'],['Other','📦']];
const $=id=>document.getElementById(id);
const money=n=>new Intl.NumberFormat('en-IN',{style:'currency',currency:'INR',maximumFractionDigits:2}).format(n||0);
const today=()=>new Date().toLocaleDateString('en-CA');
const monthNow=()=>today().slice(0,7);
let transactions=load(), selectedMonth=monthNow(), showAll=false;
function load(){try{return JSON.parse(localStorage.getItem(KEY)||'[]')}catch{return []}}
function persist(){localStorage.setItem(KEY,JSON.stringify(transactions))}
function esc(s){return String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]))}
function catEmoji(c){return (CATS.find(x=>x[0]===c)||['','📦'])[1]}
function visible(){let q=$('search').value.toLowerCase(),type=$('typeFilter').value;return transactions.filter(t=>(showAll||t.date.startsWith(selectedMonth))&&(type==='all'||t.type===type)&&(!q||(t.note+' '+t.category).toLowerCase().includes(q))).sort((a,b)=>b.date.localeCompare(a.date)||b.created-b.created)}
function render(){
 const monthTx=transactions.filter(t=>t.date.startsWith(selectedMonth));
 const inc=monthTx.filter(t=>t.type==='income').reduce((s,t)=>s+t.amount,0),out=monthTx.filter(t=>t.type==='expense').reduce((s,t)=>s+t.amount,0);
 $('balance').textContent=money(inc-out);$('income').textContent=money(inc);$('expense').textContent=money(out);
 $('categories').innerHTML=CATS.filter(c=>c[0]!=='Salary').map(([name,emoji])=>{let n=monthTx.filter(t=>t.type==='expense'&&t.category===name).reduce((s,t)=>s+t.amount,0);return `<div class="cat"><div class="emoji">${emoji}</div><b>${name}</b><small>${money(n)}</small></div>`}).join('');
 const list=visible();$('txCount').textContent=`${list.length} ${list.length===1?'entry':'entries'}`;
 $('transactions').innerHTML=list.length?list.map(t=>`<div class="tx"><div class="txicon">${catEmoji(t.category)}</div><div class="txmain"><b>${esc(t.note)}</b><small>${esc(t.category)} · ${new Date(t.date+'T12:00:00').toLocaleDateString('en-IN',{day:'numeric',month:'short',year:'numeric'})}</small></div><div class="amount ${t.type==='income'?'in':'out'}">${t.type==='income'?'+':'−'}${money(t.amount)}</div><div class="txbuttons"><button data-edit="${t.id}" aria-label="Edit">✎</button><button data-delete="${t.id}" aria-label="Delete">×</button></div></div>`).join(''):'<div class="empty">No transactions here yet.<br>Add an expense or income to get started.</div>';
 $('allMonths').textContent=showAll?'Show selected month':'Show all months';
}
function openForm(type,t=null){$('txType').value=t?t.type:type;$('txId').value=t?t.id:'';$('formTitle').textContent=t?'Edit transaction':(type==='income'?'Add income':'Add expense');$('amountInput').value=t?t.amount:'';$('noteInput').value=t?t.note:'';$('categoryInput').value=t?t.category:(type==='income'?'Salary':'Food');$('dateInput').value=t?t.date:today();$('txDialog').showModal();setTimeout(()=>$('amountInput').focus(),100)}
function closeForm(){$('txDialog').close()}
$('categoryInput').innerHTML=CATS.map(([n])=>`<option>${n}</option>`).join('');
$('monthPick').value=selectedMonth;$('monthPick').addEventListener('change',e=>{selectedMonth=e.target.value||monthNow();showAll=false;render()});
$('addExpense').onclick=()=>openForm('expense');$('addIncome').onclick=()=>openForm('income');$('closeDialog').onclick=closeForm;$('cancelDialog').onclick=closeForm;
$('txForm').addEventListener('submit',e=>{e.preventDefault();let id=$('txId').value;let entry={id:id||crypto.randomUUID(),type:$('txType').value,amount:Number($('amountInput').value),note:$('noteInput').value.trim(),category:$('categoryInput').value,date:$('dateInput').value,created:Date.now()};if(!entry.amount||entry.amount<=0||!entry.note||!entry.date)return;if(id){let i=transactions.findIndex(t=>t.id===id);if(i>=0)transactions[i]={...transactions[i],...entry,created:transactions[i].created}}else transactions.push(entry);persist();closeForm();render()});
$('transactions').addEventListener('click',e=>{let edit=e.target.closest('[data-edit]'),del=e.target.closest('[data-delete]');if(edit){let t=transactions.find(x=>x.id===edit.dataset.edit);if(t)openForm(t.type,t)}if(del){let t=transactions.find(x=>x.id===del.dataset.delete);if(t&&confirm(`Delete "${t.note}"?`)){transactions=transactions.filter(x=>x.id!==t.id);persist();render()}}});
$('search').oninput=render;$('typeFilter').onchange=render;$('allMonths').onclick=()=>{showAll=!showAll;render()};
$('exportCsv').onclick=()=>{let rows=[['Date','Type','Title','Category','Amount (INR)'],...transactions.map(t=>[t.date,t.type,t.note,t.category,t.amount])];let csv=rows.map(r=>r.map(v=>'"'+String(v).replace(/"/g,'""')+'"').join(',')).join('\r\n');let a=document.createElement('a');a.href=URL.createObjectURL(new Blob(['\ufeff'+csv],{type:'text/csv;charset=utf-8'}));a.download='paisa-transactions.csv';a.click();URL.revokeObjectURL(a.href)};
if('serviceWorker'in navigator && location.protocol!=='file:'){window.addEventListener('load',()=>navigator.serviceWorker.register('./sw.js').catch(()=>{}))}
render();